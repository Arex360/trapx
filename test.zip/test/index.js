let cam = require('pi-camera')
let axios = require('axios')
let base64 = require('image-to-base64')
let {exec} = require('child_process')
exec('sudo pigpiod')
setTimeout(()=>{
   exec('./startSensor.sh')
},5000)

const id = "client1"
let myCam = new cam({
   mode: 'photo',
   output: `${__dirname}/out2.png`,
   width: 1024,
   height: 1024,
   quality: 100,
   nopreview: true
})
setInterval(()=>{
  myCam.snap().then(res=>{
    base64(`${__dirname}/out2.png`).then(res=>{
        console.log(res)
        let out= {
            filename: 'blah',
            base64: res,
            client: id 
          }
        axios.post('http://121.52.158.157:4000',out).then(res=>{
           console.log(res.body)
           }).catch(err=>{
               console.log("error")
           }) 
      })
   }).catch(err=>{
    console.log("cam not working")
})
},10000)
