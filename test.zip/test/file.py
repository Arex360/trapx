from gpiozero import MotionSensor
pir = MotionSensor(11,threshold=0.93)
while 1:
  if pir.motion_detected:
    print("motion")
