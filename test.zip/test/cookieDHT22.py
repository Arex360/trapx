"""
Remember to start the daemon with the command
'sudo pigpiod' before running this script. It
needs to be restarted every time your pi
is restarted.
"""

import pigpio
import DHT22
from time import sleep
import datetime
#from firebase.firebase import FirebaseApplication
#from firebase.firebase import FirebaseAuthentication
from firebase import firebase

# Initiate GPIO for pigpio
pi = pigpio.pi()
# Setup the sensor
dht22 = DHT22.sensor(pi, 4) # use the actual GPIO pin name
dht22.trigger()
# Setup firebase
authentication=firebase.FirebaseAuthentication('Vh0MCAlPx4JJHhOBkwotfIdkH9SlmznRFUSDVwhE','ayesha.hakim@mnsuam.edu.pk',extra={'id':123})
fireapp=firebase.FirebaseApplication('https://smart-traps-58eac-default-rtdb.firebaseio.com/', authentication=authentication) 
# We want our sleep time to be above 2 seconds.
sleepTime = 10
TrapName="Client-1"
def readDHT22():
    # Get a new reading
    dht22.trigger()
    # Save our values
    humidity  = '%.2f' % (dht22.humidity())
    temp = '%.2f' % (dht22.temperature())
    return (humidity, temp)

while True:
    date=datetime.datetime.now().strftime('%m-%d-%Y_%H.%M.%S')
    humidity, temperature = readDHT22()
    print("Date Time is: " + date)
    print("Humidity is: " + humidity + "%")
    print("Temperature is: " + temperature + "C")           
    result=fireapp.post(TrapName,{'Date':str(date),'Temperature':str(temperature),'humidity':str(humidity)})
    print(result)
    sleep(sleepTime)
    

