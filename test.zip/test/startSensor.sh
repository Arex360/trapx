nohup python ./cookieDHT22.py &
