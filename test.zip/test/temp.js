const  sensorsLib = require('node-dht-sensor')
const app = {
   sensors: [
      {
         name: "pin1",
         type: 11,
         pin: 7
       }
     ],
   read: () =>{
       for(let sensor in this.sensors){
           let read = sensorsLib.read(
               this.sensors[sensor].type,
               this.sensors[sensor].pin)
           console.log(read.temperature.toFixed(1))
          }
       setTimeout(()=>{
           app.read()
          },2000)
      }
 }
app.read()  
